<div class="content ficha_ceatox"> <!-- Inicio da DIV content -->
    <table>
        <tbody>
            <tr>
                <td  width="300px;"><div class="bt_link_newgrande">
                        <a href="<?= base_url() ?>internacao/internacao/prescricaoemergencialenteral/<?= $internacao_id; ?>">EMERGENCIAL</a>

                        </div>
                </td>
            </tr>
            <tr>
                <td  width="300px;"><div class="bt_link_newgrande">
                        <a href="<?= base_url() ?>internacao/internacao/prescricaonormalenteral/<?= $internacao_id; ?>">NORMAL

                        </a></div>
                </td>
            </tr>
        </tbody>
    </table>

</div> <!-- Final da DIV content -->
<link rel="stylesheet" href="<?= base_url() ?>css/jquery-ui-1.8.5.custom.css">
<script type="text/javascript" src="<?= base_url() ?>js/jquery-1.9.1.js" ></script>
<script type="text/javascript" src="<?= base_url() ?>js/jquery-ui-1.10.4.js" ></script>
<script type="text/javascript" src="<?= base_url() ?>js/jquery.validate.js"></script>
<script type="text/javascript">





</script>