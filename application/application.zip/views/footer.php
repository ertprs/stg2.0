<!--<div class="footer_conteiner">
    <div class="decoration_footer"></div>
    <div class="footer">
        <h2><center>STGSa&uacute;de - Todos os direitos reservados </center></h2>
         end .footer 
    </div>
</div>-->

<!-- end .container -->

<!--<script type="text/javascript">
            (function($){
                $(function(){
            $('input:text').setMask();
        });
    })(jQuery);
</script>-->

</body>
</html>
